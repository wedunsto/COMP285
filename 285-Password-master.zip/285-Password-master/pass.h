#ifndef PASS_H
#define PASS_H

int pass(char* a);

#endif
